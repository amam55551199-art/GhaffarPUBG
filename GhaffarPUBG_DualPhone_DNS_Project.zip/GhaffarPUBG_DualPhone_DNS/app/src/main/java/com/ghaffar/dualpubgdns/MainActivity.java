package com.ghaffar.dualpubgdns;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView status, result;
    private Button test;
    private final String[] urls = {
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.google.com/generate_204"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(22), dp(18), dp(24));
        page.setBackgroundColor(Color.rgb(8,19,36));
        ScrollView scroll = new ScrollView(this);
        TextView title = text("GHAFFAR PUBG DNS", 25, true, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        page.addView(title, lp());
        TextView sub = text("دو گوشی شارپ • افغان‌بی‌سیم • PUBG Europe", 14, false, Color.rgb(173,201,235));
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0,dp(8),0,dp(18));
        page.addView(sub, lp());

        status = text("آماده برای آزمایش اتصال", 17, true, Color.WHITE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(10),dp(14),dp(10),dp(14));
        status.setBackgroundColor(Color.rgb(21,48,82));
        page.addView(status, lp());

        test = button("آزمایش اتصال، زمان پاسخ و نوسان");
        test.setOnClickListener(v -> runTest());
        page.addView(test, lp());

        Button dns = button("بازکردن تنظیمات Private DNS");
        dns.setOnClickListener(v -> openDns());
        page.addView(dns, lp());

        Button hotspot = button("راهنمای هات‌اسپات گوشی اول");
        hotspot.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("گوشی اول: شارپ + افغان‌بی‌سیم")
            .setMessage("۱. Mobile Data را روشن کن.\n۲. Hotspot را روشن کن و رمز بگذار.\n۳. گوشی دوم را به همین وای‌فای وصل کن.\n۴. اگر بازی لود نشد، Private DNS گوشی دوم را روی Automatic بگذار و دوباره آزمایش کن.\n۵. گوشی اول را نزدیک گوشی دوم نگه دار و هات‌اسپات را روی باند 2.4 GHz بگذار اگر گزینه‌اش وجود دارد.")
            .setPositiveButton("فهمیدم", null).show());
        page.addView(hotspot, lp());

        Button game = button("بازکردن PUBG Mobile");
        game.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.tencent.ig");
            if (i != null) startActivity(i);
            else Toast.makeText(this, "PUBG Mobile Global پیدا نشد یا نسخه دیگری نصب است.", Toast.LENGTH_LONG).show();
        });
        page.addView(game, lp());

        result = text("نتیجه آزمایش این‌جا نمایش داده می‌شود.\n\nاین آزمایش زمان پاسخ HTTPS را می‌سنجد، نه پینگ واقعی سرور PUBG.", 15, false, Color.WHITE);
        result.setPadding(dp(4),dp(16),dp(4),dp(16));
        page.addView(result, lp());

        TextView guide = text(
            "DNS برای آزمایش\n" +
            "Cloudflare Private DNS hostname: one.one.one.one\n\n" +
            "برای بازی از گوشی دوم، تنظیم Private DNS را روی همان گوشی دوم تغییر بده؛ تنظیم DNS روی گوشی اول لزوماً از طریق هات‌اسپات به گوشی دوم منتقل نمی‌شود.\n\n" +
            "اگر بازی وارد نشد یا اتصال بدتر شد، برگردان روی Automatic. DNS نمی‌تواند قدرت تیر یا هدشات را دستکاری کند.\n\n" +
            "کاهش لگ: بستن دانلودهای پس‌زمینه، قوی نگه‌داشتن سیگنال افغان‌بی‌سیم، نزدیک‌بودن گوشی‌ها و استفاده از فریم‌ریت پایدار کمک می‌کند.",
            14, false, Color.rgb(210,222,239));
        guide.setPadding(dp(14),dp(14),dp(14),dp(14));
        guide.setBackgroundColor(Color.rgb(17,32,52));
        page.addView(guide, lp());
        scroll.addView(page);
        setContentView(scroll);
    }

    private void runTest() {
        test.setEnabled(false);
        status.setText("در حال آزمایش ۱۰ اتصال...");
        executor.execute(() -> {
            List<Long> ok = new ArrayList<>();
            int fail = 0;
            for (String u : urls) {
                HttpURLConnection c = null;
                long start = System.nanoTime();
                try {
                    c = (HttpURLConnection)new URL(u).openConnection();
                    c.setConnectTimeout(4000);
                    c.setReadTimeout(4000);
                    c.setUseCaches(false);
                    c.setRequestProperty("Cache-Control", "no-cache");
                    int code = c.getResponseCode();
                    long ms = (System.nanoTime()-start)/1_000_000L;
                    if (code >= 200 && code < 500) ok.add(ms); else fail++;
                } catch(Exception e) { fail++; }
                finally { if(c != null) c.disconnect(); }
            }
            final List<Long> times = new ArrayList<>(ok);
            final int failures = fail;
            runOnUiThread(() -> {
                test.setEnabled(true);
                if(times.isEmpty()) {
                    status.setText("اتصال ناموفق");
                    result.setText("هیچ آزمایشی موفق نشد. اینترنت هات‌اسپات و دسترسی به اینترنت را بررسی کن.");
                    return;
                }
                Collections.sort(times);
                long sum=0, adj=0;
                for(long x:times) sum+=x;
                for(int i=1;i<times.size();i++) adj += Math.abs(times.get(i)-times.get(i-1));
                long avg=sum/times.size(), jitter=times.size()>1?adj/(times.size()-1):0;
                int loss=(int)Math.round(failures*100.0/urls.length);
                status.setText(failures==0 ? "اتصال HTTPS در این آزمایش موفق بود" : "برخی اتصال‌ها شکست خوردند");
                result.setText("موفق: "+times.size()+" از 10\nناموفق: "+failures+"\nنرخ شکست اتصال: "+loss+"%\nمیانگین زمان پاسخ: "+avg+" ms\nکمترین / بیشترین: "+times.get(0)+" / "+times.get(times.size()-1)+" ms\nنوسان تقریبی: "+jitter+" ms\n\nاین اعداد پینگ واقعی PUBG یا packet loss داخل سرور نیستند. عدد MS داخل بازی را جداگانه بررسی کن.");
            });
        });
    }

    private void openDns() {
        try { startActivity(new Intent("android.settings.PRIVATE_DNS_SETTINGS")); }
        catch(Exception e) {
            try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
            catch(Exception ignored) { Toast.makeText(this,"تنظیمات شبکه را دستی باز کن.",Toast.LENGTH_LONG).show(); }
        }
    }
    private TextView text(String s,int size,boolean bold,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24,91,158)));
        LinearLayout.LayoutParams p=lp(); p.topMargin=dp(8); b.setLayoutParams(p); return b;
    }
    private LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(-1,-2);
    }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();}
}
