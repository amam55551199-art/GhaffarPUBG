# Ghaffar PUBG DNS - دو گوشی شارپ

این پروژه برای سناریوی زیر طراحی شده است:
- گوشی اول: Sharp با سیم‌کارت افغان‌بی‌سیم، Mobile Data و Hotspot روشن.
- گوشی دوم: اتصال به Hotspot و اجرای PUBG Mobile روی سرور اروپا.

## امکانات
- ۱۰ آزمایش زمان پاسخ HTTPS، نمایش میانگین/کمینه/بیشینه و نوسان تقریبی.
- شمارش اتصال‌های ناموفق.
- دسترسی به تنظیمات Private DNS.
- راهنمای هات‌اسپات و گزینه بازکردن PUBG Mobile Global.

## نکته‌های فنی
- این پروژه سورس Android Studio است، نه APK آماده.
- تست HTTPS، پینگ واقعی PUBG یا packet loss داخل بازی را اندازه نمی‌گیرد.
- DNS را روی گوشی دوم تنظیم کن، چون DNS گوشی اول لزوماً به دستگاه متصل از طریق Hotspot اعمال نمی‌شود.
- برای آزمایش Cloudflare Private DNS hostname برابر `one.one.one.one` است. اگر بازی لود نشد یا بدتر شد، Private DNS را روی Automatic بگذار.
- DNS پینگ را تضمین نمی‌کند و نمی‌تواند hit registration یا هدشات را دستکاری کند.
- بسته PUBG Mobile Global معمولاً `com.tencent.ig` است؛ نسخه‌های دیگر ممکن است فرق داشته باشند.

## ساخت APK
پروژه را در Android Studio باز کن، Gradle Sync را کامل کن و از Build > Build APK(s) استفاده کن.
